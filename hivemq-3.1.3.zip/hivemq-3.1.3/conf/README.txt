How to use one of the sample configs
=====================================

- Copy file to <HiveMQ Home Folder>/conf
- Rename the standard config to "config-standard.xml"
- Rename the copied sample file to "config.xml"