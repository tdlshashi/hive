Quickstart
=========

Linux/Unix/MacOSX
-----------------
cd <hivemq_install_directory>/bin
chmod 755 run.sh
./run.sh


Windows
--------

Run:
Run the run.bat file by double clicking on it.



Documentation
========
The full documentation can be found here: www.hivemq.com/docs/hivemq/latest
